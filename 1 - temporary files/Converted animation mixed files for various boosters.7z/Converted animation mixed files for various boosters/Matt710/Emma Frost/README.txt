   stats {
   ailevel = 1 ;
   autospend = bruiser_light ;
   body = 6 ;
   characteranims = 198_frost ;
   charactername = Emma Frost ;
   level = 1 ;
   menulocation = 4 ;
   mind = 8 ;
   name = emma_frost_hero ;
   playable = true ;
   powerstyle = ps_frost ;
   scriptlevel = 3 ;
   skin = 19809 ;
   skin_01_name = New X-Men ;
   skin_02 = 02 ;
   skin_02_name = Classic ;
   skin_03 = 01 ;
   skin_03_name = Astonishing ;
   skin_04 = 11 ;
   skin_04_name = Ultimate ;
   sounddir = emma_m ;
   strength = 7 ;
   team = hero ;
   textureicon = 7 ;
      Race {
      name = Mutant ;
      }

      Race {
      name = XMen ;
      }

      talent {
      level = 1 ;
      name = emma_p1 ;
      }

      talent {
      level = 1 ;
      name = emma_resist ;
      }

      talent {
      level = 1 ;
      name = fightstyle_default ;
      }

      talent {
      level = 1 ;
      name = block ;
      }

      talent {
      level = 1 ;
      name = leadership ;
      }

      talent {
      level = 1 ;
      name = melee_moves ;
      }

   }