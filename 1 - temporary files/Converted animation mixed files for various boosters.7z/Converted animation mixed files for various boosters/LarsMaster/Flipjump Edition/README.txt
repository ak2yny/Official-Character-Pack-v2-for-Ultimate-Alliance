Works for every agiled character who were originally can do flip jump in comic, video games and MUA2:
-Including any MUA1 OC's & XML2 PC Characters: see below
-Does not include: Nick Fury, Cyclops, Venom every custom characters w/out permissions first
-NOTE: 91 & 33 are Hawkeye and Sabretooth's primary DLC spots
-New edited Spider-Man's combat, now can do flipjump liked in MUA2
-More will be here soon.....
-Credits goes to: Teancum, Dark_Mark, Blizz & N-Space


   stats {
   ailevel = 2 ;
   autospend = support ;
   body = 5 ;
   characteranims = 171_hawkeye ;
   charactername = Hawkeye ;
   dlchero = true ;
   level = 1 ;
   menulocation = 91 ;
   mind = 12 ;
   name = Hawkeye ;
   playable = true ;
   powerstyle = ps_hawkeye ;
   scriptlevel = 3 ;
   skin = 17101 ;
   skin_01_name = Classic ;
   skin_02 = 04 ;
   skin_02_name = Modern ;
   skin_03 = 03 ;
   skin_03_name = Street Gear ;
   skin_04 = 02 ;
   skin_04_name = Ultimate ;
   sounddir = hwkeye_m ;
   strength = 4 ;
   team = hero ;
   textureicon = 4 ;
      Race {
      name = Mutant ;
      }

      Race {
      name = XMen ;
      }

      Multipart {
      health = 0 ;
      hideskin = 20301_bow_back_segment ;
      hideskin2 = 20301_bow_L_hand_mid_segment ;
      }

      Multipart {
      health = 0 ;
      hideskin = 20301_arrow_R_hand_segment ;
      hideskin2 = 20301_ball_R_hand_segment ;
      }

      Multipart {
      health = 0 ;
      hideskin = 20301_ice_R_hand_segment ;
      hideskin2 = 20301_glue_R_hand_segment ;
      }

      Multipart {
      health = 0 ;
      hideskin = 20301_missile_R_hand_segment ;
      hideskin2 = 20301_bird_R_hand_segment ;
      }

      Multipart {
      health = 0 ;
      hideskin = 20301_bow_L_hand_segment ;
      nonmenuonly = true ;
      showskin = 20301_bow_back_segment ;
      }

      talent {
      level = 1 ;
      name = hawk_p1 ;
      }

      talent {
      level = 1 ;
      name = fightstyle_default ;
      }

      talent {
      level = 1 ;
      name = block ;
      }

      talent {
      level = 1 ;
      name = grab ;
      }

      talent {
      level = 1 ;
      name = leadership ;
      }

      talent {
      level = 1 ;
      name = melee_moves ;
      }

   }

   stats {
   ailevel = 1 ;
   autospend = bruiser ;
   body = 7 ;
   canthrowally = true ;
   characteranims = 07_captamerica ;
   charactername = Captain America ;
   level = 1 ;
   menulocation = 6 ;
   mind = 4 ;
   name = CaptainAmerica ;
   playable = true ;
   powerstyle = ps_captainamerica ;
   scriptlevel = 3 ;
   skin = 0701 ;
   skin_01_name = Ultimate ;
   skin_02 = 02 ;
   skin_02_name = Classic ;
   skin_03 = 03 ;
   skin_03_name = US Agent ;
   skin_04 = 04 ;
   skin_04_name = WW2 ;
   sounddir = captam_m ;
   strength = 10 ;
   team = hero ;
   textureicon = 5 ;
      Race {
      name = Mutant ;
      }

      Race {
      name = XMen ;
      }

      Multipart {
      showskin = shield_segment ;
      weaponevent = true ;
      }

      talent {
      level = 1 ;
      name = captam_p1 ;
      }

      talent {
      level = 1 ;
      name = block ;
      }

      talent {
      level = 1 ;
      name = melee_moves ;
      }

      talent {
      build = e3 ;
      level = 1 ;
      name = captam_p2 ;
      }

      talent {
      build = e3 ;
      level = 1 ;
      name = captam_p3 ;
      }

      talent {
      level = 1 ;
      name = fightstyle_default ;
      }

      talent {
      level = 1 ;
      name = grab ;
      }

      talent {
      level = 1 ;
      name = might ;
      }

      talent {
      descname = Crucial Strike ;
      icon = 12 ;
      name = critical ;
      }

   }

   stats {
   autospend = bruiser_light ;
   body = 7 ;
   characteranims = 06_ghostrider ;
   charactername = Ghost Rider ;
   level = 1 ;
   menulocation = 3 ;
   mind = 8 ;
   name = GhostRider ;
   playable = true ;
   powerstyle = ps_ghostrider ;
   scriptlevel = 3 ;
   skin = 0601 ;
   skin_01_name = Classic ;
   skin_02 = 02 ;
   skin_02_name = Original ;
   skin_03 = 03 ;
   skin_03_name = Vengeance ;
   skin_04 = 04 ;
   skin_04_name = Western ;
   sounddir = ghost_m ;
   strength = 6 ;
   team = hero ;
   textureicon = 4 ;
      Race {
      name = Mutant ;
      }

      Race {
      name = XMen ;
      }

      talent {
      level = 1 ;
      name = ghost_p1 ;
      }

      talent {
      level = 1 ;
      name = fightstyle_default ;
      }

      talent {
      level = 1 ;
      name = block ;
      }

      talent {
      level = 1 ;
      name = grab ;
      }

      talent {
      level = 1 ;
      name = melee_moves ;
      }

      talent {
      level = 1 ;
      name = ghost_resist ;
      }

      talent {
      build = e3 ;
      level = 1 ;
      name = ghost_p2 ;
      }

      talent {
      build = e3 ;
      level = 1 ;
      name = ghost_p7 ;
      }

      StatEffect {
      bolt = Bip01 Head ;
      effect = char/ghostr/special_burninghead ;
      fxlevel = 1 ;
      menuonly = false ;
      skin = 01 ;
      zoneonly = true ;
      }

      StatEffect {
      bolt = Bip01 Head ;
      effect = char/ghostr/special_burninghead ;
      fxlevel = 2 ;
      menuonly = true ;
      skin = 01 ;
      zoneonly = false ;
      }

      StatEffect {
      bolt = Bip01 Head ;
      effect = char/ghostr/special_burninghead ;
      fxlevel = 1 ;
      menuonly = false ;
      skin = 02 ;
      zoneonly = true ;
      }

      StatEffect {
      bolt = Bip01 Head ;
      effect = char/ghostr/special_burninghead ;
      fxlevel = 2 ;
      menuonly = true ;
      skin = 02 ;
      zoneonly = false ;
      }

      StatEffect {
      bolt = Bip01 Head ;
      effect = char/ghostr/special_burninghead ;
      fxlevel = 1 ;
      menuonly = false ;
      skin = 03 ;
      zoneonly = true ;
      }

      StatEffect {
      bolt = Bip01 Head ;
      effect = char/ghostr/special_burninghead ;
      fxlevel = 2 ;
      menuonly = true ;
      skin = 03 ;
      zoneonly = false ;
      }

      StatEffect {
      bolt = Bip01 Spine2 ;
      effect = char/ghostr/special_burninghead ;
      fxlevel = 3 ;
      skin = 04 ;
      }

   }

   stats {
   ailevel = 1 ;
   autospend = bruiser_light ;
   body = 7 ;
   characteranims = 09_spiderman ;
   charactername = Spider-Man ;
   level = 1 ;
   menulocation = 16 ;
   mind = 8 ;
   name = Spiderman ;
   playable = true ;
   powerstyle = ps_spiderman ;
   scriptlevel = 3 ;
   skin = 0901 ;
   skin_01_name = Classic ;
   skin_02 = 02 ;
   skin_02_name = Symbiote ;
   skin_03 = 03 ;
   skin_03_name = Scarlet Spider ;
   skin_04 = 04 ;
   skin_04_name = Stark Armor ;
   sounddir = spider_m ;
   strength = 6 ;
   team = hero ;
   textureicon = 7 ;
      Race {
      name = Mutant ;
      }

      Race {
      name = XMen ;
      }

      talent {
      level = 1 ;
      name = spider_p1 ;
      }

      talent {
      level = 1 ;
      name = spider_tied ;
      }

      talent {
      level = 1 ;
      name = spider_zip ;
      }

      talent {
      level = 1 ;
      name = spider_dodge ;
      }

      talent {
      level = 1 ;
      name = fightstyle_default ;
      }

      talent {
      level = 1 ;
      name = block ;
      }

      talent {
      level = 1 ;
      name = might ;
      }

      talent {
      level = 1 ;
      name = melee_moves ;
      }

      talent {
      build = e3 ;
      level = 1 ;
      name = spider_p3 ;
      }

      talent {
      build = e3 ;
      level = 1 ;
      name = spider_p7 ;
      }

      StatEffect {
      anim = menu_action ;
      bolt = Bip01 L Hand ;
      effect = char/spider/menu_idle ;
      fxlevel = 1 ;
      }

      StatEffect {
      anim = menu_idle ;
      bolt = Bip01 L Hand ;
      effect = char/spider/menu_idle ;
      fxlevel = 2 ;
      }

   }

   stats {
   ailevel = 1 ;
   autospend = bruiser ;
   body = 7 ;
   canbeallythrown = true ;
   characteranims = 03_wolverine ;
   charactername = Wolverine ;
   gen_charge_color = 0.8 0.2 0.2 1 ;
   level = 1 ;
   level_every_skill_reward = 99 ;
   menulocation = 7 ;
   mind = 4 ;
   name = Wolverine ;
   playable = true ;
   powerstyle = ps_wolverine ;
   scale_factor = 1 ;
   scriptlevel = 3 ;
   skin = 0301 ;
   skin_01_name = Modern ;
   skin_02 = 02 ;
   skin_02_name = Classic ;
   skin_03 = 03 ;
   skin_03_name = Astonishing ;
   skin_04 = 04 ;
   skin_04_name = Ultimate ;
   sounddir = wolv_m ;
   strength = 10 ;
   team = hero ;
   textureicon = 2 ;
      Race {
      name = Mutant ;
      }

      Race {
      name = XMen ;
      }

      BoltOn {
      bolt = Bip01 L Hand ;
      model = models/bolton/claw_left ;
      slot = ebolton_clawleft ;
      }

      BoltOn {
      bolt = Bip01 R Hand ;
      model = models/bolton/claw_right ;
      slot = ebolton_clawright ;
      }

      talent {
      level = 1 ;
      name = wolv_p1 ;
      }

      talent {
      level = 1 ;
      name = wolv_frenzy ;
      }

      talent {
      level = 1 ;
      name = wolv_rage ;
      }

      talent {
      level = 1 ;
      name = block ;
      }

      talent {
      level = 1 ;
      name = grab ;
      }

      talent {
      level = 1 ;
      name = might ;
      }

      talent {
      level = 1 ;
      name = healing_factor ;
      }

      talent {
      level = 1 ;
      name = melee_moves ;
      }

      talent {
      build = e3 ;
      level = 1 ;
      name = wolv_lunge ;
      }

      talent {
      build = e3 ;
      level = 1 ;
      name = wolv_p7 ;
      }

      talent {
      level = 1 ;
      name = fightstyle_default ;
      }

   }

   stats {
   ailevel = 1 ;
   autospend = bruiser ;
   body = 8 ;
   characteranims = 177_sabretooth ;
   characteranimsclass = humanoid_large ;
   charactername = Sabretooth ;
   ignoreboundsscaling = true ;
   level = 1 ;
   menulocation = 33 ;
   mind = 4 ;
   name = Sabretooth ;
   playable = true ;
   powerstyle = ps_sabretooth ;
   scale_factor = 1.1 ;
   scriptlevel = 3 ;
   skin = 17701 ;
   skin_01_name = Modern ;
   skin_02 = 04 ;
   skin_02_name = Original ;
   skin_03 = 03 ;
   skin_03_name = Age of Apocalypse ;
   skin_04 = 02 ;
   skin_04_name = Ultimate ;
   sounddir = pcsab_m ;
   strength = 9 ;
   team = hero ;
   textureicon = 7 ;
      Race {
      name = Mutant ;
      }

      Race {
      name = Brotherhood ;
      }

      talent {
      level = 1 ;
      name = sab_p1 ;
      }

      talent {
      level = 1 ;
      name = healing_factor ;
      }

      talent {
      level = 1 ;
      name = block ;
      }

      talent {
      level = 1 ;
      name = might ;
      }

      talent {
      level = 1 ;
      name = grab ;
      }

      talent {
      level = 1 ;
      name = sabre_grabsma ;
      }

      talent {
      level = 1 ;
      name = melee_moves ;
      }

      talent {
      level = 1 ;
      name = fightstyle_default ;
      }

   }

   stats {
   ailevel = 2 ;
   autospend = bruiser_light ;
   body = 7 ;
   characteranims = 148_blackwidow ;
   charactername = Black Widow ;
   level = 1 ;
   menulocation = XXXX ;
   mind = 8 ;
   name = BlackWidowv ;
   playable = true ;
   powerstyle = ps_blackwidow ;
   scriptlevel = 3 ;
   skin = 14802 ;
   skin_01_name = Ultimate ;
   skin_02 = 03 ;
   skin_02_name = Yelena Belova ;
   skin_03 = 04 ;
   skin_03_name = Natasha Romanoff ;
   skin_04 = 05 ;
   skin_04_name = Classic ;
   sounddir = bwidow_m ;
   strength = 6 ;
   team = hero ;
   textureicon = 4 ;
      Race {
      name = Mutant ;
      }

      Race {
      name = XMen ;
      }

      Multipart {
      hideskin = 20102_Mgun_segment ;
      }

      Multipart {
      hideskin = 20102_pistol_segment ;
      }

      Multipart {
      hideskin = 20102_knife_R_hand_segment ;
      }

      talent {
      level = 1 ;
      name = blackwidow_p1 ;
      }

      talent {
      level = 1 ;
      name = fightstyle_default ;
      }

      talent {
      level = 1 ;
      name = melee_moves ;
      }

      talent {
      level = 1 ;
      name = block ;
      }

      talent {
      level = 1 ;
      name = grab ;
      }

   }

   stats {
   ailevel = 1 ;
   autospend = support ;
   body = 7 ;
   characteranims = 206_bishop ;
   charactername = Bishop ;
   level = 1 ;
   menulocation = XXXX ;
   mind = 8 ;
   name = Bishop ;
   playable = true ;
   powerstyle = ps_bishop ;
   scriptlevel = 3 ;
   skin = 20601 ;
   skin_01_name = Modern ;
   skin_02 = 02 ;
   skin_02_name = Classic ;
   skin_03 = 03 ;
   skin_03_name = Age of Apocalypse ;
   skin_04 = 04 ;
   skin_04_name = Original ;
   sounddir = bishop_m ;
   strength = 6 ;
   team = hero ;
   textureicon = 5 ;
      Race {
      name = Mutant ;
      }

      Race {
      name = XMen ;
      }

      talent {
      level = 1 ;
      name = grab ;
      }

      talent {
      level = 1 ;
      name = block ;
      }

      Multipart {
      health = 0 ;
      hideskin = gun_left ;
      }

      Multipart {
      health = 0 ;
      hideskin = gun_right ;
      }

      talent {
      level = 1 ;
      name = bishop_beam ;
      }

      talent {
      level = 1 ;
      name = melee_moves ;
      }

      talent {
      level = 1 ;
      name = fightstyle_default ;
      }

   }

   stats {
   ailevel = 1 ;
   autospend = bruiser ;
   body = 7 ;
   characteranims = 209_toad ;
   charactername = Toad ;
   level = 1 ;
   menulocation = XXXX ;
   mind = 8 ;
   name = Toad ;
   playable = true ;
   powerstyle = ps_toad ;
   scriptlevel = 3 ;
   skin = 20901 ;
   skin_01_name = Ultimate ;
   skin_02 = 02 ;
   skin_02_name = Classic ;
   skin_03 = 03 ;
   skin_03_name = Age of Apocalypse ;
   skin_04 = 04 ;
   skin_04_name = Modern ;
   sounddir = toad_m ;
   strength = 6 ;
   team = hero ;
   textureicon = 5 ;
      Race {
      name = Mutant ;
      }

      Race {
      name = Brotherhood ;
      }

      talent {
      level = 1 ;
      name = grab ;
      }

      talent {
      level = 1 ;
      name = block ;
      }

      talent {
      level = 1 ;
      name = toa_donkey_kick ;
      }

      talent {
      level = 1 ;
      name = melee_moves ;
      }

      talent {
      level = 1 ;
      name = fightstyle_default ;
      }

   }
