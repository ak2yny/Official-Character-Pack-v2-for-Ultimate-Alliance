unlockHardDifficulty()
openmenu("main_beenox")
